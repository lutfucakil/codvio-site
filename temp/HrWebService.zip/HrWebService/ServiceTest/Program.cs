﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using FirebirdSql.Data.FirebirdClient;
using Newtonsoft.Json;

namespace ServiceTest
{
    /// <summary>
    /// Local veritabanı üzerinde test amaçlı çalışacak komutlar.
    /// Bu komutların çalışabilmesi için
    /// 1-) ServiceTest projesi "StartUp Project" olarak set etilmiş olmalı
    /// 2-) Local'deki Firebird sunucusunda MP2015.FDB veritabanı bulunmalı (ismi farklı olabilir)
    /// 3-) LocalConnectionString'deki şartlar sağlanmalı
    /// </summary>
    internal class Program
    {
       
        private const string LocalConnectionString = "User ID=sysdba;Password=masterkey;" +
                                                     @"Database=localhost:D:\firebird\Nuh.FDB;" +
                                                     "Charset=NONE;";

        private const string SqlHaftaTatili =
            "select r1.COMPANYID, r1.EMPNO, r2.DAYDATE, r2.LASTDATE, r2.WRKCT, r2.CALDEG, r2.WORKCONTRACT, r2.STNCALISMA, r1.CALENDAR," +
            " (CASE EXTRACT(WEEKDAY from  r3.DAYDATE-2)" +
            " WHEN 0 THEN 'PAZARTESİ' WHEN 1 THEN 'SALI' WHEN 2 THEN 'ÇARŞAMBA' WHEN 3 THEN 'PERŞEMBE' WHEN 4 THEN 'CUMA' WHEN 5 THEN 'CUMARTESİ' WHEN 6 THEN 'PAZAR' END) AS SCLEXS" +
            " from employee as r1" +
            " left join" +
            " (select a.COMPANYID, a.EMPNO, a.DAYDATE, a.LASTDATE,  b.DAYDATE-1 as CTDAYDATE,a.WORKCONTRACT as WRKCT," +
            " (CASE EXTRACT(WEEKDAY from  b.DAYDATE-2)" +
            " WHEN 0 THEN 'PAZARTESİ' WHEN 1 THEN 'SALI' WHEN 2 THEN 'ÇARŞAMBA' WHEN 3 THEN 'PERŞEMBE' WHEN 4 THEN 'CUMA' WHEN 5 THEN 'CUMARTESİ' WHEN 6 THEN 'PAZAR' END) AS CALDEG,c.WORKCONTRACT," +
            " (CASE EXTRACT(WEEKDAY from  c.xx-2)" +
            " WHEN 0 THEN 'PAZARTESİ' WHEN 1 THEN 'SALI' WHEN 2 THEN 'ÇARŞAMBA' WHEN 3 THEN 'PERŞEMBE' WHEN 4 THEN 'CUMA' WHEN 5 THEN 'CUMARTESİ' WHEN 6 THEN 'PAZAR' END) AS STNCALISMA" +
            " From empchanges as a" +
            " left join CALENDARPERIODS as  b" +
            " on a.WORKCONTRACT=b.CALENDAR and a.COMPANYID=b.COMPANYID" +
            " left join" +
            " (select k.COMPANYID,k.EMPNO, l.DAYDATE as xx, k.WORKCONTRACT from EMPLOYEE as k" +
            " inner join CALENDARPERIODS as l" +
            " on k.WORKCONTRACT=l.CALENDAR and k.COMPANYID=l.COMPANYID" +
            " )  as c" +
            " on a.COMPANYID=c.COMPANYID and a.EMPNO=c.EMPNO" +
            " WHERE ((a.LASTDATE>= '{0}' AND a.LASTDATE<='{1}') or (a.DAYDATE>='{0}' AND a.DAYDATE<='{1}'))) as r2" +
            " on r1.empno=r2.EMPNO and r1.COMPANYID=r2.COMPANYID" +
            " left join CALENDARPERIODS as  r3" +
            " on r1.CALENDAR=r3.CALENDAR and r1.COMPANYID=r3.COMPANYID" +
            " where r1.EMPNO={2} and r1.COMPANYID={3}";

        private static readonly string SqlVardiyaListe =
            @"select EE.COMPANYID, EE.EMPNO, EE.DAYDATE, EE.SCHEDULE, SC.DESCRIPTION from ENTRYEXIT as EE " +
            @"LEFT JOIN SCHEDULES as SC ON SC.SCHEDULE = EE.SCHEDULE " +
            @"WHERE EE.COMPANYID = {0} AND EE.EMPNO = {1} AND EE.DAYDATE >= '{2}' ORDER BY EE.DAYDATE";


        public static string HrVardiyaListe(int currentyear, long sicil, int companycode, string baslamaTarihi)
        {
            var sql = string.Format(SqlVardiyaListe, companycode, sicil, baslamaTarihi);
            try
            {
                using (var conn = new FbConnection(LocalConnectionString))
                {
                    conn.Open();
                    using (var command = new FbCommand(sql, conn))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            return FbDataReaderToJson(reader, new[] {2});
                        }
                    }
                }
            }
            catch (Exception e)
            {
                return $"Veritabanı Hatası: {e.Message}";
            }
        }

        public static string HrHaftaTatili(int currentyear, long sicil, int companycode, string izinbaslama,
            string izinbitis)
        {
            var sql = string.Format(SqlHaftaTatili, izinbaslama, izinbitis, sicil, companycode);
            try
            {
                using (var conn = new FbConnection(LocalConnectionString))
                {
                    conn.Open();
                    using (var command = new FbCommand(sql, conn))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            return FbDataReaderToJson(reader, new[] { 2, 3 });
                        }
                    }
                }
            }
            catch (Exception e)
            {
                return $"Veritabanı Hatası: {e.Message}";
            }
        }

        private static string FbDataReaderToJson(FbDataReader reader, int[] indices)
        {
            var table = new DataTable();
            for (var i = 0; i < reader.FieldCount; i++)
            {
                table.Columns.Add(reader.GetName(i), typeof (string));
            }

            while (reader.Read())
            {
                var row = new object[reader.FieldCount];
                for (var i = 0; i < reader.FieldCount; i++)
                {
                    var data = reader[i].ToString();
                    if (indices.Contains(i) && data != "")
                    {
                        row[i] = DateTime.Parse(data).ToString("dd.MM.yyyy");
                    }
                    else
                    {
                        row[i] = data;
                    }
                }
                table.Rows.Add(row);
            }
            reader.Close();
            return JsonConvert.SerializeObject(table);
        }

        private static string FbDataReaderToString(FbDataReader reader, int[] indices)
        {
            var sb = new StringBuilder();
            while (reader.Read())
            {
                for (var i = 0; i < reader.FieldCount; i++)
                {
                    var data = reader[i].ToString();

                    if (indices.Contains(i) && data != "")
                    {
                        sb.Append(DateTime.Parse(data).ToString("dd.MM.yyyy") + ";");
                    }
                    else
                    {
                        sb.Append(data + ";");
                    }
                }
                sb.Append("|");
            }
            reader.Close();
            return sb.Remove(sb.Length - 1, 1).ToString(); //Remove the last row seperator '|'
        }
        

        private static void Main(string[] args)
        {
            var str = HrVardiyaListe(2015, 1366, 1, "15.11.2015");

            //var str = HrHaftaTatili(2015, 60230, 1, "25.11.2015", "10.12.2015");

            Console.WriteLine(str);
        }
    }
}