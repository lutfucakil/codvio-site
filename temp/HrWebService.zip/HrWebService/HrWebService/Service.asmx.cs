﻿using System;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Web.Services;
using FirebirdSql.Data.FirebirdClient;
using Newtonsoft.Json;

namespace HrWebService
{
    /// <summary>
    ///     Summary description for Service
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class Service : WebService
    {
        private const string ConnectionString = "User ID=sysdba;Password=m;" +
                                                "Database=172.26.1.67:D:\\MPuantor\\Veri\\MP{0}.FDB; " +
                                                "DataSource=172.26.1.67;Charset=NONE;";

        private const string SqlVardiyaListe =
            @"select EE.COMPANYID, EE.EMPNO, EE.DAYDATE, EE.SCHEDULE, SC.DESCRIPTION from ENTRYEXIT as EE " +
            @"LEFT JOIN SCHEDULES as SC ON SC.SCHEDULE = EE.SCHEDULE " +
            @"WHERE EE.COMPANYID = {0} AND EE.EMPNO = {1} AND EE.DAYDATE >= '{2}' ORDER BY EE.DAYDATE";

        private const string SqlHaftaTatili =
            "select r1.COMPANYID, r1.EMPNO, r2.DAYDATE, r2.LASTDATE, r2.WRKCT, r2.CALDEG, r2.WORKCONTRACT, r2.STNCALISMA, r1.CALENDAR," +
            " (CASE EXTRACT(WEEKDAY from  r3.DAYDATE-2)" +
            " WHEN 0 THEN 'PAZARTESİ' WHEN 1 THEN 'SALI' WHEN 2 THEN 'ÇARŞAMBA' WHEN 3 THEN 'PERŞEMBE' WHEN 4 THEN 'CUMA' WHEN 5 THEN 'CUMARTESİ' WHEN 6 THEN 'PAZAR' END) AS SCLEXS" +
            " from employee as r1" +
            " left join" +
            " (select a.COMPANYID, a.EMPNO, a.DAYDATE, a.LASTDATE,  b.DAYDATE-1 as CTDAYDATE,a.WORKCONTRACT as WRKCT," +
            " (CASE EXTRACT(WEEKDAY from  b.DAYDATE-2)" +
            " WHEN 0 THEN 'PAZARTESİ' WHEN 1 THEN 'SALI' WHEN 2 THEN 'ÇARŞAMBA' WHEN 3 THEN 'PERŞEMBE' WHEN 4 THEN 'CUMA' WHEN 5 THEN 'CUMARTESİ' WHEN 6 THEN 'PAZAR' END) AS CALDEG,c.WORKCONTRACT," +
            " (CASE EXTRACT(WEEKDAY from  c.xx-2)" +
            " WHEN 0 THEN 'PAZARTESİ' WHEN 1 THEN 'SALI' WHEN 2 THEN 'ÇARŞAMBA' WHEN 3 THEN 'PERŞEMBE' WHEN 4 THEN 'CUMA' WHEN 5 THEN 'CUMARTESİ' WHEN 6 THEN 'PAZAR' END) AS STNCALISMA" +
            " From empchanges as a" +
            " left join CALENDARPERIODS as  b" +
            " on a.WORKCONTRACT=b.CALENDAR and a.COMPANYID=b.COMPANYID" +
            " left join" +
            " (select k.COMPANYID,k.EMPNO, l.DAYDATE as xx, k.WORKCONTRACT from EMPLOYEE as k" +
            " inner join CALENDARPERIODS as l" +
            " on k.WORKCONTRACT=l.CALENDAR and k.COMPANYID=l.COMPANYID" +
            " )  as c" +
            " on a.COMPANYID=c.COMPANYID and a.EMPNO=c.EMPNO" +
            " WHERE ((a.LASTDATE>= '{0}' AND a.LASTDATE<='{1}') or (a.DAYDATE>='{0}' AND a.DAYDATE<='{1}'))) as r2" +
            " on r1.empno=r2.EMPNO and r1.COMPANYID=r2.COMPANYID" +
            " left join CALENDARPERIODS as  r3" +
            " on r1.CALENDAR=r3.CALENDAR and r1.COMPANYID=r3.COMPANYID" +
            " where r1.EMPNO={2} and r1.COMPANYID={3}";

        [WebMethod]
        public string HrVardiyaListe(int currentyear, long sicil, int companycode, string baslamaTarihi)
        {
            var connStr = string.Format(ConnectionString, currentyear);
            var sql = string.Format(SqlVardiyaListe, companycode, sicil, baslamaTarihi);
            try
            {
                using (var conn = new FbConnection(connStr))
                {
                    conn.Open();
                    using (var command = new FbCommand(sql, conn))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            return FbDataReaderToString(reader, new[] {2});
                        }
                    }
                }
            }
            catch (Exception e)
            {
                return $"Veritabanı Hatası: {e.Message}";
            }
        }


        [WebMethod]
        public string HrVardiyaListeJson(int currentyear, long sicil, int companycode, string baslamaTarihi)
        {
            var connStr = string.Format(ConnectionString, currentyear);
            var sql = string.Format(SqlVardiyaListe, companycode, sicil, baslamaTarihi);
            try
            {
                using (var conn = new FbConnection(connStr))
                {
                    conn.Open();
                    using (var command = new FbCommand(sql, conn))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            return FbDataReaderToJson(reader, new[] {2});
                        }
                    }
                }
            }
            catch (Exception e)
            {
                return $"Veritabanı Hatası: {e.Message}";
            }
        }

        [WebMethod]
        public string HrHaftaTatili(int currentyear, long sicil, int companycode, string izinbaslama, string izinbitis)
        {
            var connStr = string.Format(ConnectionString, currentyear);
            var sql = string.Format(SqlHaftaTatili, izinbaslama, izinbitis, sicil, companycode);
            try
            {
                using (var conn = new FbConnection(connStr))
                {
                    conn.Open();
                    using (var command = new FbCommand(sql, conn))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            return FbDataReaderToString(reader, new[] {2, 3});
                        }
                    }
                }
            }
            catch (Exception e)
            {
                return $"Veritabanı Hatası: {e.Message}";
            }
        }

        [WebMethod]
        public string HrHaftaTatiliJson(int currentyear, long sicil, int companycode, string izinbaslama,
            string izinbitis)
        {
            var connStr = string.Format(ConnectionString, currentyear);
            var sql = string.Format(SqlHaftaTatili, izinbaslama, izinbitis, sicil, companycode);
            try
            {
                using (var conn = new FbConnection(connStr))
                {
                    conn.Open();
                    using (var command = new FbCommand(sql, conn))
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            return FbDataReaderToJson(reader, new[] {2, 3});
                        }
                    }
                }
            }
            catch (Exception e)
            {
                return $"Veritabanı Hatası: {e.Message}";
            }
        }

        private static string FbDataReaderToString(FbDataReader reader, int[] indices)
        {
            var sb = new StringBuilder();
            while (reader.Read())
            {
                for (var i = 0; i < reader.FieldCount; i++)
                {
                    var data = reader[i].ToString();

                    if (indices.Contains(i) && data != "")
                    {
                        sb.Append(DateTime.Parse(data).ToString("dd.MM.yyyy") + ";");
                    }
                    else
                    {
                        sb.Append(data + ";");
                    }
                }
                sb.Append("|");
            }
            return sb.Remove(sb.Length - 1, 1).ToString(); //Remove the last row seperator '|'
        }

        private static string FbDataReaderToJson(FbDataReader reader, int[] indices)
        {
            var table = new DataTable();
            for (var i = 0; i < reader.FieldCount; i++)
            {
                table.Columns.Add(reader.GetName(i), typeof (string));
            }

            while (reader.Read())
            {
                var row = new object[reader.FieldCount];
                for (var i = 0; i < reader.FieldCount; i++)
                {
                    var data = reader[i].ToString();
                    if (indices.Contains(i) && data != "")
                    {
                        row[i] = DateTime.Parse(data).ToString("dd.MM.yyyy");
                    }
                    else
                    {
                        row[i] = data;
                    }
                }
                table.Rows.Add(row);
            }
            return JsonConvert.SerializeObject(table);
        }
    }
}